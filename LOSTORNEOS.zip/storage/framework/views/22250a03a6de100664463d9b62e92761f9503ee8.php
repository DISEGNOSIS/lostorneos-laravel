<?php $__env->startSection('title'); ?>
    Los Torneos - <?php echo e($team->display_name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <!-- CSS rules for styling the element inside the editor such as p, h1, h2, etc. -->
    <link href="../css/froala_style.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
        <div class="tournament-main">
            <div class="tournament show">
                <div class="col-3">
                    <h2 class="tournament-title">
                        <a href="<?php echo e(route('teams.show', $team->name)); ?>"><?php echo e($team->display_name); ?></a>
                    </h2>
                    <?php if($team->image): ?>
                        <div class="centrar">
                            <a href="<?php echo e(route('teams.show', $team->name)); ?>">
                                <img src="<?php echo e(asset('storage/img/teams/' . $team->image)); ?>" class="image" alt="<?php echo e($team->name); ?>"/>
                            </a>
                        </div>
                    <?php endif; ?>
                    <span><img src="<?php echo e(asset('img/flags/' . $team->country->flag)); ?>" class="image" alt="<?php echo e($team->country->name); ?>"/></span>

                                        

                </div>
                <div class="fr-view">
                    <?php echo $team->description; ?>

                </div>
                <div class="tournament-teams">
                    <h3>JUGADORES:</h3>
                    <div class="tournament-teams-data">
                        <?php $__currentLoopData = $team->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tournament-team-data">
                                <h2><?php echo e($user->username); ?></h2>
                                <img src="<?php echo e(asset('storage/img/avatar/' . $user->avatar)); ?>" class="image" alt="<?php echo e($user->username); ?>"/>
                                <div class="tournament-footer">
                                    <span class="flag"><img src="<?php echo e(asset('img/flags/' . $user->country->flag)); ?>" class="image-flag" alt="<?php echo e($user->country->name); ?>"/></span>
                                    <p><i class="fas fa-gamepad"></i>&nbsp; <?php echo e($user->score); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
	</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>