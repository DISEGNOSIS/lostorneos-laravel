<?php $__env->startSection('title'); ?>
    Los Torneos - Crear Torneo.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <!-- Include external CSS. -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.25.0/codemirror.min.css">
 
    <!-- Include Editor style. -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/froala-editor/2.8.4/css/froala_editor.pkgd.min.css" rel="stylesheet" type="text/css" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/froala-editor/2.8.4/css/froala_style.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <article>        
            <div class="botones">
                <button type="submit" form="tournaments-create">Guardar</button>
                <a href="<?php echo e(route('my-account')); ?>">Cancelar</a>
            </div>
            <h1>Crear Torneo</h1>
            <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <section class="formulario1">
                <form id="tournaments-create" action="<?php echo e(route('tournaments.store')); ?>" method="POST" enctype="multipart/form-data" data-parsley-validate>
                    <?php echo csrf_field(); ?>
                    <?php if($errors->has('name')): ?>
                        <p class="error" role="alert">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </p>
                    <?php endif; ?>
                    <div class="campo">
                        <input id="name" type="text" class="<?php echo e($errors->has('name') ? ' error' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" placeholder="Nombre" autofocus required/>
                    </div>
                    <?php if($errors->has('game')): ?>
                        <p class="error" role="alert">
                            <strong><?php echo e($errors->first('game')); ?></strong>
                        </p>
                    <?php endif; ?>
                    <div class="custom-select">
                        <select name="game" required>
                            <option value="" disabled selected>Juego:</option>
                            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($game->id); ?>"><?php echo e($game->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="custom-select">
                        <select name="country" required>
                            <option value="" disabled selected>País:</option>
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div id="image" class="campo">
                        <input type="file" name="image" value="<?= isset($_FILES["image"]["name"]) ? $_FILES["image"]["name"] : "" ?>" accept="image/*">
                    </div>
                    <?php if($errors->has('prize')): ?>
                        <p class="error" role="alert">
                            <strong><?php echo e($errors->first('prize')); ?></strong>
                        </p>
                    <?php endif; ?>
                    <div class="campo">
                        <input id="prize" type="text" class="<?php echo e($errors->has('prize') ? ' error' : ''); ?>" name="prize" value="<?php echo e(old('prize')); ?>" placeholder="Premio" autofocus/>
                    </div>
                    <?php if($errors->has('information')): ?>
                        <span class="error" role="alert">
                            <strong><?php echo e($errors->first('information')); ?></strong>
                        </span>
                    <?php endif; ?>
                    <div class="campo">
                        <textarea id="my-editor" class="<?php echo e($errors->has('information') ? ' error' : ''); ?>" name="information" placeholder="Información..." rows="10" autofocus><?php echo e(old('information')); ?></textarea>
                    </div>
                    <br/>
                    <?php if($errors->has('start')): ?>
                    <p class="error" role="alert">
                        <strong><?php echo e($errors->first('start')); ?></strong>
                    </p>
                    <?php endif; ?>
                    <div class="campo">
                        <input id="datepicker" type="text" class="<?php echo e($errors->has('start') ? ' error' : ''); ?>" name="start" value="<?php echo e(old('start')); ?>" placeholder="Comienza" autofocus required/>
                    </div>
                    <?php if($errors->has('end')): ?>
                    <p class="error" role="alert">
                        <strong><?php echo e($errors->first('end')); ?></strong>
                    </p>
                    <?php endif; ?>
                    <div class="campo">
                        <input id="datepicker1" type="text" class="<?php echo e($errors->has('end') ? ' error' : ''); ?>" name="end" value="<?php echo e(old('end')); ?>" placeholder="Finaliza" autofocus required/>
                    </div>
                    
                </form>
            </section>
        </article>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="/js/select.js"></script>
    <!-- Include external JS libs. -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.25.0/codemirror.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.25.0/mode/xml/xml.min.js"></script>
 
    <!-- Include Editor JS files. -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/froala-editor/2.8.4/js/froala_editor.pkgd.min.js"></script>
 
    <!-- Initialize the editor. -->
    <script> $(function() { $('textarea').froalaEditor({
        language: 'es',

        heightMin: 300,
        imageMove: true,
        imageUploadParam: 'file',
        imageUploadMethod: 'post',
        // Set the image upload URL.
        imageUploadURL: '/file-upload',
        imageUploadParams: {
            froala: 'true', // This allows us to distinguish between Froala or a regular file upload.
            _token: "<?php echo e(csrf_token()); ?>" // This passes the laravel token with the ajax request.
        }
    }) });
    </script>

    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
    $( function() {
        $( "#datepicker" ).datepicker();
        $( "#datepicker1" ).datepicker();
    } );
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>