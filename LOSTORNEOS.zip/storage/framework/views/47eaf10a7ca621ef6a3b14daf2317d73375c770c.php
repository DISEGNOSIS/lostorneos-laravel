<?php $__env->startSection('title'); ?>
    Los Torneos - <?php echo e($tournament->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <!-- CSS rules for styling the element inside the editor such as p, h1, h2, etc. -->
    <link href="../css/froala_style.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
        <div class="tournament-main">
            <div class="tournament show">
                <h2 class="tournament-title">
                    <a href="<?php echo e(route('tournaments.show', $tournament->slug)); ?>"><?php echo e($tournament->name); ?></a>
                </h2>
                <div class="tournament-info">
                    <span class="tournament-game"><a href="<?php echo e(route('tournaments.games.show', $tournament->game->slug)); ?>"><?php echo e($tournament->game->name); ?></a></span>
                    <span><img src="<?php echo e(asset('img/flags/' . $tournament->country->flag)); ?>" class="image" alt="<?php echo e($tournament->country->name); ?>"/></span>
                </div>
                <div class="col-3">
                    <div class="tags">
                        <?php $__currentLoopData = $tournament->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="tournament-tag"><a href="<?php echo e(route('tournaments.tags.show', $tag->slug)); ?>"><?php echo e($tag->name); ?></a></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php if($tournament->image): ?>
                        <div class="centrar">
                            <a href="<?php echo e(route('tournaments.show', $tournament->slug)); ?>">
                                <img src="<?php echo e(asset('storage/img/tournaments/' . $tournament->image)); ?>" class="image" alt="<?php echo e($tournament->name); ?>"/>
                            </a>
                        </div>
                    <?php endif; ?>
                    <div class="dates">
                        <?php if($tournament->prize): ?>
                            <div class="tournament-price">
                                <i class="fas fa-trophy"></i>&nbsp; $<?php echo e($tournament->prize); ?>

                            </div>
                        <?php endif; ?>
                        <p class="tournament-meta"><i class="far fa-calendar-alt"></i>&nbsp; 
                            Inicio: <?php echo e(\Carbon\Carbon::parse($tournament->start)->format('d-m-Y H:i')); ?>hs
                        </p>
                        <p class="tournament-meta"><i class="far fa-calendar-alt"></i>&nbsp; 
                            Fin: <?php echo e(\Carbon\Carbon::parse($tournament->end)->format('d-m-Y H:i')); ?>hs
                        </p>
                    </div>
                </div>
                <div class="fr-view">
                    <?php echo $tournament->information; ?>

                </div>
                <div class="tournament-teams">
                    <h3>EQUIPOS:</h3>
                    <div class="tournament-teams-data">
                    <?php $__currentLoopData = $tournament->teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tournament-team-data">
                            <h2><a href="<?php echo e(route('teams.show', $team->name)); ?>"><?php echo e($team->display_name); ?></a></h2>
                            <a href="<?php echo e(route('teams.show', $team->name)); ?>">
                                <img src="<?php echo e(asset('storage/img/teams/' . $team->image)); ?>" class="image" alt="<?php echo e($team->display_name); ?>"/>
                            </a>
                            <div class="tournament-footer">
                                <span class="flag"><img src="<?php echo e(asset('img/flags/' . $team->country->flag)); ?>" class="image" alt="<?php echo e($team->country->name); ?>"/></span>
                                <p><i class="fas fa-gamepad"></i>&nbsp; <?php echo e($team->score); ?></p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
	</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>