<?php $__env->startSection('title'); ?>
    Los Torneos - <?php echo e($category->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <!-- CSS rules for styling the element inside the editor such as p, h1, h2, etc. -->
    <link href="../css/froala_style.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
        <h1 class="titulo"><?php echo e($category->name); ?>:</h1>
        <?php if($category->posts->count() > 0): ?>
            <div class="blog-main">
                <?php $__currentLoopData = $category->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="blog-post">
                        <h2 class="blog-post-title">
                            <a href="/posts/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a>
                        </h2>
                        <div class="blog-post-info">
                            <span class="blog-post-category"><a href="<?php echo e(route('posts.show', $post->slug)); ?>"><?php echo e($post->category->name); ?></a></span>
                            <span class="blog-post-meta">
                                <?php echo e($post->user->username); ?> ::
                                <?php echo e(\Carbon\Carbon::parse($post->published_at)->diffForHumans()); ?>

                            </span>
                        </div>
                        <?php if($post->image): ?>
                            <div class="centrar">
                                <a href="<?php echo e(route('posts.show', $post->slug)); ?>">
                                    <a href="<?php echo e(route('posts.show', $post->slug)); ?>">
                                        <img src="<?php echo e(asset('storage/img/posts/' . $post->image)); ?>" class="image" alt="<?php echo e($post->title); ?>"/>
                                    </a>
                                </a>
                            </div>
                        <?php endif; ?>
                        <div class="fr-view">
                            <?php echo str_limit(strip_tags($post->content), 333); ?>

                        </div>
                        <div class="blog-post-footer">
                            <div class="tags">
                                <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p class="blog-post-tag"><a href="<?php echo e(route('posts.tags.show', $tag->slug)); ?>"><?php echo e($tag->name); ?></a></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php if(strlen(strip_tags($post->content)) > 333): ?>                        
                                <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="read-more">
                                    <i class="fas fa-arrow-alt-circle-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
	</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>