<?php $__env->startSection('title'); ?>
    Administración | Usuarios - Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="botones">
        <button type="submit" form="admin-users-edit">Guardar</button>
        <a href="<?php echo e(route('admin.users')); ?>">Cancelar</a>
    </div>
    <h1>Editar Usuario</h1>
    <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <article class="col-2">
        <section class="left">
            <img src="<?php echo e(asset('storage/img/avatar/' . $user->avatar)); ?>" alt="Foto Perfil" class="imagen-usuario" />
            <a id="change-avatar">Cambiar la Imagen de Perfil</a>
            <a id="change-password">Cambiar la Contraseña</a>
        </section>
        <section class="formulario right">
            <form id="admin-users-edit" action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="campo">
                    <label for="name">Nombre:</label>
                    <input id="name" type="text" class="<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($user->name ? $user->name : old('name')); ?>" placeholder="Nombre" autofocus/>
                    <?php if($errors->has('name')): ?>
                        <span class="error" role="alert">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="campo">
                    <label for="username">Usuario:</label>
                    <input id="username" type="text" class="<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e($user->username); ?>" placeholder="Usuario" required autofocus/>

                    <?php if($errors->has('username')): ?>
                        <span class="error" role="alert">
                            <strong><?php echo e($errors->first('username')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="campo">
                    <label for="email">e-Mail:</label>
                    <input id="email" type="email" class="<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($user->email); ?>" placeholder="Email" required/>

                    <?php if($errors->has('email')): ?>
                        <span class="error" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="campo">
                    <label for="country">País:</label>
                </div>
                <div class="custom-select">
                    <select name="country">
                       <option value="" disabled>País</option>
                       <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($user->country_id == $country->id): ?>
                                <option value="<?php echo e($country->id); ?>" selected><?php echo e($country->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                            <?php endif; ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                	</select>
                </div>
                <div class="campo">
                    <label for="role">Rol:</label>
                </div>
                <div class="custom-select">
                    <select name="role">
                        <option value="" disabled>Rol</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($user->roles[0]->id == $role->id): ?>
                                <option value="<?php echo e($role->id); ?>" selected><?php echo e($role->display_name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->display_name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="campo">
                    <label for="score">Puntuación:</label>
                    <input id="score" type="text" class="<?php echo e($errors->has('score') ? ' is-invalid' : ''); ?>" name="score" value="<?php echo e($user->score ? $user->score : old('score')); ?>" placeholder="Puntuación" autofocus/>

                    <?php if($errors->has('score')): ?>
                        <span class="error" role="alert">
                            <strong><?php echo e($errors->first('score')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div id="password" class="campo hidden">
                    <label for="password">Contraseña:</label>
                    <input type="password" class="password <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="Contraseña"/>

                    <?php if($errors->has('password')): ?>
                        <span class="error" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div id="password_confirmation" class="campo hidden">
                    <label for="password_confirmation">Confirmar Contraseña:</label>
                    <input type="password" class="password" name="password_confirmation" placeholder="Confirmar Contraseña"/>
                </div>
                <div id="avatar" class="campo hidden">
                    <label for="avatar">Avatar:</label>
                    <input type="file" name="avatar" value="<?= isset($_FILES["avatar"]["name"]) ? $_FILES["avatar"]["name"] : "" ?>" accept="image/*">
                </div>
            </form>
        </section>
	</article>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="/js/admin-user-edit.js"></script>
    <script src="/js/select.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>