<?php $__env->startSection('title'); ?>
    Administración - Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
		<h1>Panel de Administración de Los Torneos</h1>
		<section class="juegos">
				<?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<figure><img src="/img/games/<?php echo e($game->image); ?>" alt="<?php echo e($game->name); ?>"></figure>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</section>
	</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>