<?php $__env->startSection('title'); ?>
    Administración | Permisos - Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
        <div class="editar">
            <a href="<?php echo e(route('admin.permissions.edit', $permission->id)); ?>">Editar</a>
        </div>
        <h1>Detalles del Permiso: <?php echo e($permission->display_name); ?></h1>
        <section>
            <div class="mi-cuenta">
                <div class="datos-usuario">
                    <h2>ID: &nbsp; <span><?php echo e($permission->id); ?></span></h2>
                    <?php if($permission->description): ?>
                        <h2>Descripción: &nbsp; <span><?php echo e($permission->description); ?></span></h2>
                    <?php endif; ?>
                </div>
            </div>
        </section>
	</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>