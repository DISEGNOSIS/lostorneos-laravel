<?php $__env->startSection('title'); ?>
    Administración | Usuarios - Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
        <div class="editar">
            <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>">Editar</a>
        </div>
        <h1><?php echo e($user->username); ?></h1>
        <section class="formulario">
            <div class="mi-cuenta">
                <img src="<?php echo e(asset('storage/img/avatar/' . $user->avatar)); ?>" alt="Foto Perfil" class="imagen-usuario" />
                <div class="datos-usuario">
                    <h2>ID: &nbsp; <span><?php echo e($user->id); ?></span></h2>
                    <?php if($user->name): ?>
                        <h2>Nombre: &nbsp; <span><?php echo e($user->name); ?></span></h2>
                    <?php endif; ?>
                    <h2>e-Mail: &nbsp; <span><?php echo e($user->email); ?></span></h2>
                    <h2>País: &nbsp; <span><?php echo e($user->country->name); ?></span></h2>
                    <?php if($user->score): ?>
                        <h2>Puntuación: &nbsp; <span><?php echo e($user->score); ?></span></h2>
                    <?php endif; ?>
                    <h2>Rol: &nbsp; <span><?php echo e($user->roles[0]->display_name); ?></span></h2>
                </div>
            </div>
        </section>
	</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>