<?php $__env->startSection('title'); ?>
    Ingresá a Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php $estilo = ""; ?>
    <main>
		<article>
			<h1>Ingresá a tu Cuenta:</h1>
			<section class="formulario">
				<form action="" method="post" action="<?php echo e(route('login')); ?>" id="ingreso">
					<?php echo csrf_field(); ?>
					<div class="error"><?= isset($errores["usuario"]) ? $errores["usuario"]: "" ?></div>
					<?php if($errors->has('username')): ?>
						<p class="error" role="alert">
							<strong><?php echo e($errors->first('username')); ?></strong>
						</p>
					<?php endif; ?>
					<div class="campo">
						<input id="username" type="text" class="<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" placeholder="Usuario" required autofocus/>
					</div>
					<?php if($errors->has('password')): ?>
						<p class="error" role="alert">
							<strong><?php echo e($errors->first('password')); ?></strong>
						</p>
					<?php endif; ?>
					<div class="campo">
						<input id="password" type="password" class="<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="Contraseña" required/>

					</div>
					<div class="campo1">
						<div class="checkbox">
							<input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

							<label for="remember">
								<?php echo e(__('Recordarme')); ?>

							</label>
						</div>
						<a href="<?php echo e(route('password.request')); ?>">
                            <?php echo e(__('¿Olvidaste la Contraseña?')); ?>

                        </a>
					</div>
					<div class="campo">
						<button type="submit" form="ingreso" value="ingresar">Ingresar</button>
					</div>
				</form>
				<hr>
				<h2>Podés ingresar con:</h2>
				<div class="social-login">
					<div class="discord-login">
						<a href="<?php echo e(route('discord')); ?>"><i class="fab fa-discord"></i></a>
					</div>
					<div class="facebook-login">
						<a href="<?php echo e(route('facebook')); ?>"><i class="fab fa-facebook-square"></i></a>
					</div>
					<div class="github-login">
						<a href="<?php echo e(route('github')); ?>"><i class="fab fa-github-square"></i></a>
					</div>
				</div>
			</section>
		</article>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>