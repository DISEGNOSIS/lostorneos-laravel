<?php $__env->startSection('title'); ?>
    Administración | Categorías - Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <article>
        <h1 class="listado">Categorías:</h1>
        
        <div class="new">
            <a href="<?php echo e(route('admin.categories.create')); ?>"><i class="fas fa-plus-square"></i> Nueva Categoría</a>
        </div>
        <?php if($categories->count() > 0): ?>
            <table id="table" class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Título</th>
                        <th>Editar</th>
                        <th>Borrar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($category->id); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.categories.show', $category->id)); ?>"><?php echo e($category->name); ?></a>
                            </td>
                            <td>
                                <a class="edit" href="<?php echo e(route('admin.categories.edit', $category->id)); ?>"><i class="fas fa-edit"></i></a>
                            </td>
                            <td>    
                                <form action="<?php echo e(route('admin.categories.destroy', $category->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="delete" href=""><i class="fas fa-trash-alt"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <h2>No se han encontrado Categorías</h2>    
        <?php endif; ?>
    </article>
    <?php if($categories->count() > 0): ?>
        <?php echo e($categories->links()); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>