<?php $__env->startSection('title'); ?>
    Administración | Usuarios - Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
	<article>
        <h1 class="listado">Usuarios:</h1>
        <?php echo $__env->make('layouts.admin-partials.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="new">
            <a href="<?php echo e(route('admin.users.create')); ?>"><i class="fas fa-plus-square"></i> Nuevo Usuario</a>
        </div>
        <?php if($users->count() > 0): ?>
            <table id="table" class="table">
                <thead>
                    <tr>
                        <th><i class="fas fa-cog"></i></th>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Usuario</th>
                        <th>e-Mail</th>
                        <th>País</th>
                        <th>Creado</th>
                        <th>Último Ingreso</th>
                        <th>Rol</th>
                        <th>Editar</th>
                        <th>Borrar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('admin.users.active', $user->id)); ?>"><i class="fas <?php echo e($user->active ? 'fa-check' : 'fa-times'); ?>"></i></a>
                            </td>
                            <td><?php echo e($user->id); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.users.show', $user->id)); ?>"><?php echo e($user->name ? $user->name : ''); ?></a>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.users.show', $user->id)); ?>"><?php echo e($user->username); ?></a>
                            </td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <img src="/img/flags/<?php echo e($user->country ? strtolower($user->country->flag) : ''); ?>" alt="<?php echo e($user->country ? $user->country->name : ''); ?>" class="flag"/>
                            </td>
                            <td><?php echo e(\Carbon\Carbon::parse($user->created_at)->diffForHumans()); ?></td>
                            <td>
                                <?php echo e($user->last_sign_in ? \Carbon\Carbon::parse($user->last_sign_in)->diffForHumans() : '-'); ?>

                            </td>
                            <td><?php echo e($user->roles[0]->display_name); ?></td>
                            <td>
                                <a class="edit" href="<?php echo e(route('admin.users.edit', $user->id)); ?>"><i class="fas fa-edit"></i></a>
                            </td>
                            <td>    
                                <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="delete" href=""><i class="fas fa-trash-alt"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <h2>No se han encontrado usuarios</h2>    
        <?php endif; ?>
    </article>
    <div id="pagination">
        <?php if($users->count() > 0): ?>
            <?php echo e($users->links()); ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/ajax-users.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>