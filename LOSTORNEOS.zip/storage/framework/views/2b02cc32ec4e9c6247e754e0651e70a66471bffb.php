<?php $__env->startSection('title'); ?>
    Administración | Permisos - Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
        <div class="botones">
            <button type="submit" form="admin-permissions-create">Guardar</button>
            <a href="<?php echo e(route('admin.permissions')); ?>">Cancelar</a>
        </div>
        <h1>Crear un Permiso</h1>
        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <section class="formulario">
            <form id="admin-permissions-create" action="<?php echo e(route('admin.permissions.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php if($errors->has('display_name')): ?>
                    <p class="error" role="alert">
                        <strong><?php echo e($errors->first('display_name')); ?></strong>
                    </p>
                <?php endif; ?>
                <div class="campo">
                    <input id="display_name" type="text" class="<?php echo e($errors->has('display_name') ? ' is-invalid' : ''); ?>" name="display_name" value="<?php echo e(old('display_name')); ?>" placeholder="Título" autofocus/>
                </div>
                <?php if($errors->has('description')): ?>
                    <p class="error" role="alert">
                        <strong><?php echo e($errors->first('description')); ?></strong>
                    </p>
                <?php endif; ?>
                <div class="campo">
                    <textarea id="description" class="<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" placeholder="Descripción" autofocus><?php echo e(old('description')); ?></textarea>
                </div>
            </form>
        </section>
	</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>