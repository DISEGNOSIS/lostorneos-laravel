<?php $__env->startSection('title'); ?>
    Administración | Permisos - Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<article>
        <h1 class="listado">Permisos:</h1>
        
        <div class="new">
            <a href="<?php echo e(route('admin.permissions.create')); ?>"><i class="fas fa-plus-square"></i> Nuevo Permiso</a>
        </div>
        <?php if($permissions->count() > 0): ?>
            <table id="table" class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Título</th>
                        <th>Editar</th>
                        <th>Borrar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($permission->id); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.permissions.show', $permission->id)); ?>"><?php echo e($permission->display_name); ?></a>
                            </td>
                            <td>
                                <a class="edit" href="<?php echo e(route('admin.permissions.edit', $permission->id)); ?>"><i class="fas fa-edit"></i></a>
                            </td>
                            <td>    
                                <form action="<?php echo e(route('admin.permissions.destroy', $permission->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="delete" href=""><i class="fas fa-trash-alt"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <h2>No se han encontrado permisos</h2>    
        <?php endif; ?>
    </article>
    <?php if($permissions->count() > 0): ?>
        <?php echo e($permissions->links()); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>