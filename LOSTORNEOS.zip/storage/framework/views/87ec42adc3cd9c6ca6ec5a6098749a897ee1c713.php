<?php $__env->startSection('title'); ?>
    Administración | Tags - Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
        <div class="botones">
            <button type="submit" form="admin-tags-create">Guardar</button>
            <a href="<?php echo e(route('admin.tags')); ?>">Cancelar</a>
        </div>
        <h1>Crear un Tag</h1>
        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <section class="formulario">
            <form id="admin-tags-create" action="<?php echo e(route('admin.tags.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php if($errors->has('name')): ?>
                    <p class="error" role="alert">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </p>
                <?php endif; ?>
                <div class="campo">
                    <input id="name" type="text" class="<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" placeholder="Título" autofocus required/>
                </div>
            </form>
        </section>
	</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>