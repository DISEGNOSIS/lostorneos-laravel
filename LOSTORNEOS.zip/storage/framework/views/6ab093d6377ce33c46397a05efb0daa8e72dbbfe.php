<?php $__env->startSection('title'); ?>
    Administración | Noticias - Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
	<article>
        <h1 class="listado">Noticias:</h1>
        <?php echo $__env->make('layouts.admin-partials.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="new">
            <a href="<?php echo e(route('admin.posts.create')); ?>"><i class="fas fa-plus-square"></i> Nueva Noticia</a>
        </div>
        <?php if($posts->count() > 0): ?>
            <table id="table" class="table">
                <thead>
                    <tr>
                        <th><i class="fas fa-cog"></i></th>
                        <th>ID</th>
                        <th>Título</th>
                        <th>Categoría</th>
                        <th>Usuario</th>
                        <th>Publicado</th>
                        <th>Creado</th>
                        <th>Editar</th>
                        <th>Borrar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('admin.posts.active', $post->id)); ?>"><i class="fas <?php echo e($post->active ? 'fa-check' : 'fa-times'); ?>"></i></a>
                            </td>
                            <td><?php echo e($post->id); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.posts.show', $post->id)); ?>"><?php echo e($post->title); ?></a>
                            </td>
                            <td>
                                <a href=""><?php echo e($post->category['name']); ?></a>
                            </td>
                            <td><?php echo e($post->user['username']); ?></td>
                            <td><?php echo e($post->published_at ? \Carbon\Carbon::parse($post->published_at)->diffForHumans() : '-'); ?>

                            </td>
                            <td><?php echo e(\Carbon\Carbon::parse($post->created_at)->diffForHumans()); ?></td>
                            <td>
                                <a class="edit" href="<?php echo e(route('admin.posts.edit', $post->id)); ?>"><i class="fas fa-edit"></i></a>
                            </td>
                            <td>    
                                <form action="<?php echo e(route('admin.posts.destroy', $post->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="delete" href=""><i class="fas fa-trash-alt"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <h2>No se han encontrado posts</h2>    
        <?php endif; ?>
    </article>
    <div id="pagination">
        <?php if($posts->count() > 0): ?>
            <?php echo e($posts->links()); ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/ajax-posts.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>