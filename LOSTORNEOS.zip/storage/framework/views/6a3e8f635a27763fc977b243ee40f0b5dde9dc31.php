<?php $__env->startSection('title'); ?>
    Administración | Permisos - Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
        <div class="botones">
            <button type="submit" form="admin-permissions-edit">Guardar</button>
            <a href="<?php echo e(route('admin.permissions')); ?>">Cancelar</a>
        </div>
        <h1>Editar un Permiso</h1>
        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <section class="formulario">
            <form id="admin-permissions-edit" action="<?php echo e(route('admin.permissions.update', $permission->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="campo">
                    <label for="display_name">Nombre:</label>
                    <input id="display_name" type="text" class="<?php echo e($errors->has('display_name') ? ' is-invalid' : ''); ?>" name="display_name" value="<?php echo e($permission->display_name ? $permission->display_name : old('display_name')); ?>" placeholder="Título" autofocus/>
                    <?php if($errors->has('display_name')): ?>
                        <span class="error" role="alert">
                            <strong><?php echo e($errors->first('display_name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="campo">
                    <label for="name">Slug:</label>
                    <input id="name" type="text" class="<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($permission->name ? $permission->name : old('name')); ?>" placeholder="Slug" autofocus disabled/>
                    <?php if($errors->has('name')): ?>
                        <span class="error" role="alert">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="campo">
                    <label for="description">Descripción:</label>
                    <textarea id="description" class="<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" placeholder="Description" autofocus><?php echo e($permission->description ? $permission->description : old('description')); ?></textarea>
                    <?php if($errors->has('description')): ?>
                        <span class="error" role="alert">
                            <strong><?php echo e($errors->first('description')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </form>
        </section>
	</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>