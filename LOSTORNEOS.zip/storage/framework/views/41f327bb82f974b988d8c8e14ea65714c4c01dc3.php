<?php $__env->startSection('title'); ?>
    Administración | Categorías - Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
        <div class="editar">
            <a href="<?php echo e(route('admin.categories.edit', $category->id)); ?>">Editar</a>
        </div>
        <section>
            <div class="mi-cuenta">
                <div class="datos-usuario">
                    <h2>ID: &nbsp; <span><?php echo e($category->id); ?></span></h2>
                    <h1><?php echo e($category->name); ?></h1>
                </div>
            </div>
        </section>
	</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>