<?php $__env->startSection('title'); ?>
    Administración | Roles - Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
        <div class="botones">
            <button type="submit" form="admin-roles-edit">Guardar</button>
            <a href="<?php echo e(route('admin.roles')); ?>">Cancelar</a>
        </div>
        <h1>Editar un Rol</h1>
        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <section class="formulario">
            <form id="admin-roles-edit" action="<?php echo e(route('admin.roles.update', $role->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="campo">
                    <label for="display_name">Nombre:</label>
                    <input id="display_name" type="text" class="<?php echo e($errors->has('display_name') ? ' is-invalid' : ''); ?>" name="display_name" value="<?php echo e($role->display_name ? $role->display_name : old('display_name')); ?>" placeholder="Título" autofocus/>
                    <?php if($errors->has('display_name')): ?>
                        <span class="error" role="alert">
                            <strong><?php echo e($errors->first('display_name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="campo">
                    <label for="name">Slug:</label>
                    <input id="name" type="text" class="<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($role->name ? $role->name : old('name')); ?>" placeholder="Slug" autofocus disabled/>
                    <?php if($errors->has('name')): ?>
                        <span class="error" role="alert">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="campo">
                    <label for="description">Descripción:</label>
                    <textarea id="description" class="<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" placeholder="Description" autofocus><?php echo e($role->description ? $role->description : old('description')); ?></textarea>
                    <?php if($errors->has('description')): ?>
                        <span class="error" role="alert">
                            <strong><?php echo e($errors->first('description')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <h2>Permisos:</h2>
                <div class="datos-checkbox">
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="container"><?php echo e($permission->display_name); ?>

                            <input type="checkbox" name="permissions[]" value="<?php echo e($permission->id); ?>" <?php echo e($role->permissions->contains($permission->id) ? 'checked="checked"' : ''); ?>>
                            <span class="check-box"></span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </form>
        </section>
	</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>