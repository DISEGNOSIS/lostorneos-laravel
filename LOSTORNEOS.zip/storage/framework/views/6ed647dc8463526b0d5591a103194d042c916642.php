<?php $__env->startSection('title'); ?>
    Administración | Noticias - Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <!-- CSS rules for styling the element inside the editor such as p, h1, h2, etc. -->
    <link href="../css/froala_style.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
        <div class="editar">
            <a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>">Editar</a>
        </div>
        <h1><?php echo e($post->title); ?></h1>
        <section class="post">
            <?php if($post->image): ?>
                <img src="<?php echo e(asset('storage/img/posts/' . $post->image)); ?>" class="image" alt="<?php echo e($post->title); ?>"/>
            <?php endif; ?>
            <div class="fr-view">
                <?php echo $post->content; ?>

            </div>
        </section>
	</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>