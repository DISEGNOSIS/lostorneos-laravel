<a href="#" class="toggle-nav">
    <span class="ion-navicon-round">
        <img src="/img/nav-icon.png" alt="Menú"/>
    </span>
</a>
<nav class="main-nav">
    <ul class="nav">
        <li class="dropdown-button <?php echo e(Nav::isRoute('admin.users')); ?>"><a href="<?php echo e(route('admin.users')); ?>"><i class="fas fa-users"></i>&nbsp; Usuarios <i class="fas fa-caret-down"></i></a>
            <ul id="dropdown">
                <li class="<?php echo e(Nav::isRoute('admin.roles')); ?>"><a href="<?php echo e(route('admin.roles')); ?>"><i class="fas fa-users-cog"></i>&nbsp; Roles</a></li>
                <li class="<?php echo e(Nav::isRoute('admin.permissions')); ?>"><a href="<?php echo e(route('admin.permissions')); ?>"><i class="fas fa-users-cog"></i>&nbsp; Permisos</a></li>
            </ul>
        </li>
        <li class="<?php echo e(Nav::isRoute('admin.posts')); ?>"><a href="<?php echo e(route('admin.posts')); ?>"><i class="far fa-newspaper"></i>&nbsp; Noticias <i class="fas fa-caret-down"></i></a>
            <ul id="dropdown">
                <li class="<?php echo e(Nav::isRoute('admin.categories')); ?>"><a href="<?php echo e(route('admin.categories')); ?>"><i class="fas fa-newspaper"></i>&nbsp; Categorías</a></li>
                <li class="<?php echo e(Nav::isRoute('admin.tags')); ?>"><a href="<?php echo e(route('admin.tags')); ?>"><i class="fas fa-tags"></i>&nbsp; Tags</a></li>
            </ul>
        </li>
        <li class=""><a href=""><i class="fas fa-users-cog"></i>&nbsp; Equipos</a></li>
        <li class=""><a href=""><i class="fas fa-users-cog"></i>&nbsp; Partidos</a></li>
    </ul>
</nav>