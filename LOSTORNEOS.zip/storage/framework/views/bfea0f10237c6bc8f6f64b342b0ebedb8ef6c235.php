<?php $__env->startSection('title'); ?>
    Administración | Roles - Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
        <div class="botones">
            <button type="submit" form="admin-roles-create">Guardar</button>
            <a href="<?php echo e(route('admin.roles')); ?>">Cancelar</a>
        </div>
        <h1>Crear un Rol</h1>
        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <section class="formulario">
            <form id="admin-roles-create" action="<?php echo e(route('admin.roles.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php if($errors->has('display_name')): ?>
                    <p class="error" role="alert">
                        <strong><?php echo e($errors->first('display_name')); ?></strong>
                    </p>
                <?php endif; ?>
                <div class="campo">
                    <input id="display_name" type="text" class="<?php echo e($errors->has('display_name') ? ' is-invalid' : ''); ?>" name="display_name" value="<?php echo e(old('display_name')); ?>" placeholder="Título" autofocus/>
                </div>
                <?php if($errors->has('description')): ?>
                    <p class="error" role="alert">
                        <strong><?php echo e($errors->first('description')); ?></strong>
                    </p>
                <?php endif; ?>
                <div class="campo">
                    <textarea id="description" class="<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" placeholder="Descripción" autofocus><?php echo e(old('description')); ?></textarea>
                </div>
                <h2>Permisos:</h2>
                <div class="datos-checkbox">
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="container"><?php echo e($permission->display_name); ?>

                            <input type="checkbox" name="permissions[]" value="<?php echo e($permission->id); ?>">
                            <span class="check-box"></span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </form>
        </section>
	</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>