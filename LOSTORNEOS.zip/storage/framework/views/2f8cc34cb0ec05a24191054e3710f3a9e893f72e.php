<?php $__env->startSection('title'); ?>
    Los Torneos - Mis Torneos.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <!-- CSS rules for styling the element inside the editor such as p, h1, h2, etc. -->
    <link href="../css/froala_style.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
        <h1 class="titulo">Mis Torneos</h1>
        <?php if($tournaments->count() > 0): ?>
            <div class="tournament-main">
                <?php $__currentLoopData = $tournaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tournament">
                        <h2 class="tournament-title">
                            <a href="<?php echo e(route('tournaments.show', $tournament->slug)); ?>"><?php echo e($tournament->name); ?></a>
                        </h2>
                        <div class="tournament-info">
                            <span class="tournament-game"><a href="<?php echo e(route('tournaments.games.show', $tournament->game->slug)); ?>"><?php echo e($tournament->game->name); ?></a></span>
                            <span class="tournament-meta">
                                <?php echo e(\Carbon\Carbon::parse($tournament->start)->diffForHumans()); ?>

                            </span>
                        </div>
                        <?php if($tournament->image): ?>
                        <div class="centrar">
                            <img src="<?php echo e(asset('storage/img/tournaments/' . $tournament->image)); ?>" class="image" alt="<?php echo e($tournament->name); ?>"/>
                        </div>
                        <?php endif; ?>
                        <?php if($tournament->prize): ?>
                            <div class="tournament-price"><i class="fas fa-trophy"></i>&nbsp; $<?php echo e($tournament->prize); ?></div>
                        <?php endif; ?>
                        <div class="fr-view">
                            <?php echo str_limit(strip_tags($tournament->information), 200); ?>

                        </div>
                        <div class="tournament-footer">
                            <div class="tags">
                                <?php $__currentLoopData = $tournament->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p class="tournament-tag"><a href="<?php echo e(route('tournaments.tags.show', $tag->slug)); ?>"><?php echo e($tag->name); ?></a></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php if(strlen(strip_tags($tournament->information)) > 200): ?>                        
                                <a href="<?php echo e(route('tournaments.show', $tournament->slug)); ?>" class="read-more">
                                    <i class="fas fa-arrow-alt-circle-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <h2>No se han encontrado Torneos</h2>    
        <?php endif; ?>
    </article>
    <div id="pagination">
        <?php if($tournaments->count() > 0): ?>
            <?php echo e($tournaments->links()); ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>