<nav class="sidebar">
    <ul>
        <li><a href="<?php echo e(route('admin.users')); ?>"><i class="fas fa-users"></i>&nbsp; Usuarios</a></li>
        <li><a href="http://"><i class="fas fa-users-cog"></i>&nbsp; Roles & Permisos</a></li>
    </ul>
</nav>