<a href="#" class="toggle-nav">
    <span class="ion-navicon-round">
        <img src="/img/nav-icon.png" alt="Menú"/>
    </span>
</a>
<nav class="main-nav">
    <ul>
        <li class="<?php echo e(Nav::isRoute('home')); ?>"><a href="<?php echo e(route('home')); ?>"><i class="fas fa-home"></i></a></li>
        <li class="<?php echo e(Nav::isResource('tournaments')); ?>"><a href="<?php echo e(route('tournaments')); ?>"><i class="fas fa-trophy"></i>&nbsp; Torneos</a></li>
        <li class="<?php echo e(Nav::isResource('teams')); ?>"><a href="<?php echo e(route('teams')); ?>"><i class="fas fa-gamepad"></i>&nbsp; Equipos</a></li>
        <li class="<?php echo e(Nav::isResource('posts')); ?>"><a href="<?php echo e(route('posts')); ?>"><i class="far fa-newspaper"></i>&nbsp; Noticias</a></li>
        <li class="<?php echo e(Nav::isRoute('faq')); ?>"><a href="<?php echo e(route('faq')); ?>"><i class="fas fa-question"></i>&nbsp; Ayuda</a></li>
        
    </ul>
</nav>