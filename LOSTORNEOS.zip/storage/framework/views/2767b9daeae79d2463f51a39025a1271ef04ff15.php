<div class="search">
    <form method="GET">
        
        <i class="fa fa-search" aria-hidden="true"></i>
        <input id="query" type="text" name="query" value="<?php echo e(old('query')); ?>" placeholder="Buscar..."/>
        <i class="fas fa-times" id="reset"></i>
    </form>
</div>