<?php $__env->startSection('title'); ?>
    Los Torneos - Equipos.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
        <h1 class="titulo">Equipos</h1>
        <?php if($teams->count() > 0): ?>
            <div class="tournament-main">
                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tournament">
                        <h2 class="tournament-title">
                            <a href="<?php echo e(route('teams.show', $team->name)); ?>"><?php echo e($team->display_name); ?></a>
                        </h2>
                        <?php if($team->image): ?>
                        <div class="centrar">
                            <a href="<?php echo e(route('teams.show', $team->name)); ?>">
                                <img src="<?php echo e(asset('storage/img/teams/' . $team->image)); ?>" class="image" alt="<?php echo e($team->display_name); ?>"/>
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <h2>No se han encontrado Equipos</h2>    
        <?php endif; ?>
    </article>
    <div id="pagination">
        <?php if($teams->count() > 0): ?>
            <?php echo e($teams->links()); ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>