<?php $__env->startSection('title'); ?>
    Los Torneos - <?php echo e($post->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <!-- CSS rules for styling the element inside the editor such as p, h1, h2, etc. -->
    <link href="../css/froala_style.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
        <div class="blog-main">
            <div class="blog-post show">
                <h2 class="blog-post-title">
                    <a href="/posts/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a>
                </h2>
                <div class="blog-post-info">
                    <span class="blog-post-category"><a href="<?php echo e(route('posts.show', $post->slug)); ?>"><?php echo e($post->category->name); ?></a></span>
                    <span class="blog-post-meta">
                        <?php echo e($post->user->username); ?> ::
                        <?php echo e(\Carbon\Carbon::parse($post->published_at)->diffForHumans()); ?>

                    </span>
                </div>
                <?php if($post->image): ?>
                    <div class="centrar">
                        <img src="<?php echo e(asset('storage/img/posts/' . $post->image)); ?>" class="image" alt="<?php echo e($post->title); ?>"/>
                    </div>
                <?php endif; ?>
                <div class="fr-view">
                    <?php echo $post->content; ?>

                </div>
            </div>
            
        </div>
	</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>