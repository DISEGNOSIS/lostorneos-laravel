<?php
	$estilo = "";
?>



<?php $__env->startSection('title'); ?>
    Registrate en Los Torneos.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
	<link rel="stylesheet" href="/css/parsley.css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<main>
		<article>
			<h1>Creá tu Cuenta:</h1>
			<section class="formulario">
				<form id="registro" action="<?php echo e(route('register')); ?>" method="POST" aria-label="<?php echo e(__('Register')); ?>" enctype="multipart/form-data" data-parsley-validate>
					<?php echo csrf_field(); ?>
					<div class="campo">
						<input id="name" type="text" class="<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" placeholder="Nombre" autofocus minlength="3" maxlength="255"/>
					</div>
					<?php if($errors->has('name')): ?>
						<p class="error" role="alert">
							<strong><?php echo e($errors->first('name')); ?></strong>
						</p>
					<?php endif; ?>
					<div class="campo">
						<input id="username" type="text" class="<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" placeholder="Usuario" required autofocus minlength="2" maxlength="255"/>
					</div>
					<?php if($errors->has('username')): ?>
						<p class="error" role="alert">
							<strong><?php echo e($errors->first('username')); ?></strong>
						</p>
					<?php endif; ?>
					<div class="campo">
						<input id="email" type="email" class="<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" required/>
					</div>
					<?php if($errors->has('email')): ?>
						<p class="error" role="alert">
							<strong><?php echo e($errors->first('email')); ?></strong>
						</p>
					<?php endif; ?>
					<div class="campo">
						<input id="password" type="password" class="<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="Contraseña" required minlength="6"/>
					</div>
					<?php if($errors->has('password')): ?>
						<p class="error" role="alert">
							<strong><?php echo e($errors->first('password')); ?></strong>
						</p>
					<?php endif; ?>
					<div class="campo">
						<input id="password-confirm" type="password" name="password_confirmation" placeholder="Confirmar Contraseña" required>
					</div>
					<div class="custom-select">
						<select name="country" required>
						   <option value="" disabled>País</option>
						   <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
								<?php if($country->id == 10): ?>
									<option value="<?php echo e($country->id); ?>" selected><?php echo e($country->name); ?></option>
								<?php else: ?>
									<option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
								<?php endif; ?>
						   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					<div class="campo">
						<input type="file" name="avatar" value="<?= isset($_FILES["avatar"]["name"]) ? $_FILES["avatar"]["name"] : "" ?>" accept="image/*">
					</div>
					<?php if($errors->has('avatar')): ?>
						<p class="error" role="alert">
							<strong><?php echo e($errors->first('avatar')); ?></strong>
						</p>
					<?php endif; ?>
					<div class="campo">
						<button type="submit" form="registro" value="registrarme">Registrarme</button>
						<button type="reset" form="registro" value="reset">Borrar</button>
					</div>
				</form>
			</section>
		</article>
	</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script src="/js/select.js"></script>
	<script src="/js/parsley.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>