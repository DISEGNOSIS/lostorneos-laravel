<?php $__env->startSection('title'); ?>
    Administración | Roles - Los Torneos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<article>
        <div class="editar">
            <a href="<?php echo e(route('admin.roles.edit', $role->id)); ?>">Editar</a>
        </div>
        <h1>Detalles del Rol: <?php echo e($role->display_name); ?></h1>
        <section>
            <div class="mi-cuenta">
                <div class="datos-usuario">
                    <h2>ID: &nbsp; <span><?php echo e($role->id); ?></span></h2>
                    <?php if($role->description): ?>
                        <h2>Descripción: &nbsp; <span><?php echo e($role->description); ?></span></h2>
                    <?php endif; ?>
                </div>
            </div>
            <?php if($role->permissions->count() > 0): ?>
                <h2>Permisos:</h2>
                <div class="datos-checkbox">
                    <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="container"><?php echo e($r->display_name); ?>

                            <input type="checkbox" checked="checked" disabled>
                            <span class="check-box"></span>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </section>
	</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>