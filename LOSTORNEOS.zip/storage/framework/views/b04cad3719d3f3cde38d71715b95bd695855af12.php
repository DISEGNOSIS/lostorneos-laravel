<?php $__env->startSection('title'); ?>
    Mi Cuenta en Los Torneos.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
		<article>
			<div class="editar">
                <a 	href="<?php echo e(route('tournaments.create')); ?>"><i class="fas fa-plus-square"></i> Crear Torneo</a>
            </div>
            <div class="mis-torneos">
				<a 	href="<?php echo e(route('tournaments.user', Auth::user()->id)); ?>"><i class="fas fa-trophy"></i> Mis Torneos</a>
			</div>
			<h1>Mi Cuenta</h1>
			<section class="formulario">
                <div class="mi-cuenta">
                    <img src="<?php echo e(asset('storage/img/avatar/' . Auth::user()->avatar)); ?>" alt="Foto Perfil" class="imagen-usuario" />
                    <div class="datos-usuario">
                        <h2>Usuario: &nbsp; <span><?php echo e(Auth::user()->username); ?></span></h2>
                        <h2>e-Mail: &nbsp; <span><?php echo e(Auth::user()->email); ?></span></h2>
                        <h2>País: &nbsp; <span><?php echo e(Auth::user()->country->name); ?> </span><img src="<?php echo e(asset('img/flags/' . Auth::user()->country->flag)); ?>" alt="<?php echo e(Auth::user()->country->name); ?>"/></h2>
                        <?php if(Auth::user()->score): ?>
                            <h2>Puntuación: <span>&nbsp; <?php echo e(Auth::user()->score); ?></span> &nbsp;<i class="fas fa-gamepad"></i></h2>
                        <?php endif; ?>
                        <h2>Rol: &nbsp; <span><?php echo e(Auth::user()->roles[0]->display_name); ?></span></h2>
                    </div>
                </div>
			</section>
		</article>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>